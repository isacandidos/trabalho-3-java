/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho03;

import java.util.Random;

/**
 *
 * @author isadora
 */
public class Medieval extends Personagem implements Curavel{
    public Medieval() {
        super("Gualterius", 90, 18);
    }
      @Override
      public void atacar(Personagem p) {
        System.out.println(getNome() + " ataca " + p.getNome() + " causando " + getAtaque() + " de dano!");
        p.setVida(p.getVida() - getAtaque());
    }
      @Override
    
  
public void curar() {
        int cura = new Random().nextInt(20) + 1;
        setVida(getVida() + cura);
        System.out.println(getNome() + " se curou em " + cura + " pontos de vida.");
}
}