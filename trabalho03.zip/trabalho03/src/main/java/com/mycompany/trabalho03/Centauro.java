/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho03;

/**
 *
 * @author isadora
 */
public class Centauro extends Lobisomem {
    public Centauro() {
        

    super.setNome("Helatea");
    super.setVida(120);
    super.setAtaque(25);
    }
}
