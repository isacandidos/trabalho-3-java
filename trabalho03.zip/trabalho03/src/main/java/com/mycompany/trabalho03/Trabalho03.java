/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho03;

import java.util.Random;

/**
 *
 * @author isadora
 */

public class Trabalho03 {

    public static void main(String[] args) {
        Personagem jogador = new Lobisomem();
        Personagem computador = new Medieval();
        Random random = new Random();
        System.out.println("Início do Jogo: " + jogador.getNome() + " VS " + computador.getNome());
        while (jogador.estaVivo() && computador.estaVivo()) {
            System.out.println("\nTurno do Jogador!");
            jogador.atacar(computador);}
        
        if (!computador.estaVivo()) {
                System.out.println(computador.getNome() + " foi derrotado! " + jogador.getNome() + " venceu!");
              
            }
        if (jogador instanceof Curavel && random.nextBoolean()) {
                ((Curavel) jogador).curar();
            }
         System.out.println("\nTurno do Computador!");
            computador.atacar(jogador);
            if (!jogador.estaVivo()) {
                System.out.println(jogador.getNome() + " foi derrotado! " + computador.getNome() + " venceu!");
                
            }
             if (computador instanceof Curavel && random.nextBoolean()) {
                ((Curavel) computador).curar();
            }
            
    
}}
