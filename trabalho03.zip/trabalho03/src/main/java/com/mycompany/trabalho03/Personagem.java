/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho03;

/**
 *
 * @author isadora
 */
public abstract class Personagem {
    final String nome;
    public int vida;
    public final int ataque;
    
      public Personagem(String nome, int vida, int ataque) {
        this.nome = nome;
        this.vida = vida;
       this.ataque = ataque;
    }

    public String getNome() {
        return nome;
    }
    public int getVida() {
        return vida;
    }
    public void setVida(int vida) {
        this.vida = Math.max(0, vida);
    }
    public int getAtaque() {
        return ataque;
    }
  public abstract void atacar(Personagem p);
  public boolean estaVivo() {
        return vida > 0;
    }
}
